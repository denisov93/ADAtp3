import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;

public class Tale{
	
	Map<Integer, LinkedList<NodeAndDistance>> friendships;
	int P;
	boolean[] selected;
	int[] length;
	int[] via;
	Queue<NodeAndDistance> connected;
	int counter;
	
	@SuppressWarnings("unchecked")
	public Tale(int people) {
		counter = 0;
		P = people;
		friendships = new HashMap<>(P);
		selected = new boolean[P];
		length = new int[P];
		via = new int[P];
		connected = new PriorityQueue(P, new NodeComparator());
	}
	
	public void addPerson(String[] splited) {
		Integer person = Integer.parseInt(splited[0]);
		LinkedList<NodeAndDistance> ls = friendships.get(person);
		if(ls==null) {
			ls = new LinkedList<NodeAndDistance>();
		}
		friendships.put(person, ls);
		
		length[counter]=Integer.MAX_VALUE;
		selected[counter]=false;
	}

	public void addFriendship(String[] splited) {
		Integer person = Integer.parseInt(splited[0]);
		int friend = Integer.parseInt(splited[1]);
		
		LinkedList<NodeAndDistance> ls = friendships.get(person);
		
		NodeAndDistance nd = ls.removeFirst();
		NodeAndDistance	newNode = new NodeAndDistance(person,friend);
		if(nd!=null) {				
			ls.addFirst(nd);
			ls.addLast(newNode);
		}
		else {
			ls.add(newNode);
		}
	}
	
	public void dikstra() {
		length[0] = 0;
		via[0] = 0;
		NodeAndDistance node = friendships.get(0).getFirst(); 
		connected.add(node);
		do {
			node = connected.remove();
			int to = node.getNodeTo();
			selected[to] = true;
			exploreNode(node);
			
		}while(!connected.isEmpty());
	}
	
	public void exploreNode(NodeAndDistance node) {
		int to = node.getNodeTo();
		List<NodeAndDistance>ls = friendships.get(to);
		for(NodeAndDistance n : ls) {
			int nD = n.getNodeTo();
			if(!selected[nD]) {
				//int newLength = length[]
			}
		}
	}
	
	
	
	
}
